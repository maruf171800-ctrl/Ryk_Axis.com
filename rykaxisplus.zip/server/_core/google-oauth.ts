import { createRemoteJWKSet, jwtVerify, SignJWT } from "jose";
import type { Express, Request, Response } from "express";
import { parse as parseCookieHeader } from "cookie";
import { createHmac, timingSafeEqual } from "node:crypto";
import * as db from "../db";
import { getSessionCookieOptions } from "./cookies";
import { ENV } from "./env";

export const GOOGLE_SESSION_COOKIE = "ryk_axis_google_session";
const GOOGLE_STATE_COOKIE = "ryk_axis_google_state";
const ONE_YEAR_MS = 365 * 24 * 60 * 60 * 1000;
const GOOGLE_JWKS = createRemoteJWKSet(new URL("https://www.googleapis.com/oauth2/v3/certs"));

type GoogleClaims = {
  sub: string;
  email: string;
  email_verified?: boolean;
  name?: string;
  picture?: string;
};

function getQueryParam(req: Request, key: string): string | undefined {
  const value = req.query[key];
  return typeof value === "string" ? value : undefined;
}

function safeReturnTo(value: string | undefined) {
  return value && value.startsWith("/") && !value.startsWith("//") ? value : "/seller";
}

function signOAuthState(nonce: string, returnTo: string) {
  const payload = Buffer.from(JSON.stringify({ nonce, returnTo, exp: Date.now() + 10 * 60 * 1000 }), "utf8").toString("base64url");
  const signature = createHmac("sha256", getGoogleSessionSecret()).update(payload).digest("base64url");
  return `${payload}.${signature}`;
}

function decodeSignedOAuthState(value: string): { nonce: string; returnTo: string } | null {
  try {
    const [payload, encodedSignature] = value.split(".");
    if (!payload || !encodedSignature) return null;
    const expectedSignature = createHmac("sha256", getGoogleSessionSecret()).update(payload).digest("base64url");
    const received = Buffer.from(encodedSignature, "base64url");
    const expected = Buffer.from(expectedSignature, "base64url");
    if (received.length !== expected.length || !timingSafeEqual(received, expected)) return null;
    const parsed = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
    if (typeof parsed.nonce !== "string" || typeof parsed.returnTo !== "string" || typeof parsed.exp !== "number" || parsed.exp < Date.now()) return null;
    return { nonce: parsed.nonce, returnTo: safeReturnTo(parsed.returnTo) };
  } catch {
    return null;
  }
}

function getGoogleSessionSecret() {
  const secret = process.env.GOOGLE_OAUTH_CLIENT_SECRET;
  if (!secret) throw new Error("GOOGLE_OAUTH_CLIENT_SECRET is unavailable");
  return new TextEncoder().encode(`${secret}:ryk-axis-session`);
}

async function createGoogleSession(claims: GoogleClaims) {
  return new SignJWT({
    provider: "google",
    sub: claims.sub,
    email: claims.email,
    name: claims.name ?? "",
  })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setIssuedAt()
    .setExpirationTime("1y")
    .sign(getGoogleSessionSecret());
}

export async function verifyGoogleSession(token: string | undefined | null): Promise<GoogleClaims | null> {
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, getGoogleSessionSecret(), { algorithms: ["HS256"] });
    const sub = typeof payload.sub === "string" ? payload.sub : null;
    const email = typeof payload.email === "string" ? payload.email : null;
    if (!sub || !email) return null;
    return { sub, email, name: typeof payload.name === "string" ? payload.name : "" };
  } catch {
    return null;
  }
}

export function registerGoogleOAuthRoutes(app: Express) {
  app.get("/api/auth/google/start", (req: Request, res: Response) => {
    const clientId = process.env.GOOGLE_OAUTH_CLIENT_ID;
    if (!clientId) {
      res.status(503).json({ error: "Google OAuth is not configured" });
      return;
    }

    const nonce = crypto.randomUUID();
    const returnTo = safeReturnTo(getQueryParam(req, "returnTo"));
    const state = signOAuthState(nonce, returnTo);
    const cookieOptions = getSessionCookieOptions(req);
    res.cookie(GOOGLE_STATE_COOKIE, nonce, { ...cookieOptions, maxAge: 10 * 60 * 1000 });

    const url = new URL("https://accounts.google.com/o/oauth2/v2/auth");
    url.searchParams.set("client_id", clientId);
    url.searchParams.set("redirect_uri", ENV.googleRedirectUri);
    url.searchParams.set("response_type", "code");
    url.searchParams.set("scope", "openid email profile");
    url.searchParams.set("state", state);
    url.searchParams.set("prompt", "select_account");
    res.redirect(302, url.toString());
  });

  app.get("/api/auth/google/callback", async (req: Request, res: Response) => {
    const code = getQueryParam(req, "code");
    const state = getQueryParam(req, "state");
    const stateCookie = parseCookieHeader(req.headers.cookie ?? "")[GOOGLE_STATE_COOKIE];
    const signedState = state ? decodeSignedOAuthState(state) : null;

    // The signed state is the source of truth. The cookie remains an extra
    // browser binding when available, but some embedded/preview browsers drop
    // SameSite cookies during the Google round trip.
    if (!code || !state || !signedState || (stateCookie && stateCookie !== signedState.nonce)) {
      res.status(403).json({ error: "Invalid Google OAuth state" });
      return;
    }
    res.clearCookie(GOOGLE_STATE_COOKIE, getSessionCookieOptions(req));

    try {
      const clientId = process.env.GOOGLE_OAUTH_CLIENT_ID;
      const clientSecret = process.env.GOOGLE_OAUTH_CLIENT_SECRET;
      if (!clientId || !clientSecret) throw new Error("Google OAuth credentials are unavailable");

      const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          code,
          client_id: clientId,
          client_secret: clientSecret,
          redirect_uri: ENV.googleRedirectUri,
          grant_type: "authorization_code",
        }),
      });
      if (!tokenResponse.ok) throw new Error(`Google token exchange failed (${tokenResponse.status})`);
      const tokenPayload = await tokenResponse.json() as { id_token?: string };
      if (!tokenPayload.id_token) throw new Error("Google did not return an ID token");

      const { payload } = await jwtVerify(tokenPayload.id_token, GOOGLE_JWKS, {
        issuer: ["https://accounts.google.com", "accounts.google.com"],
        audience: clientId,
      });
      const claims: GoogleClaims = {
        sub: typeof payload.sub === "string" ? payload.sub : "",
        email: typeof payload.email === "string" ? payload.email.toLowerCase() : "",
        email_verified: payload.email_verified === true,
        name: typeof payload.name === "string" ? payload.name : "",
        picture: typeof payload.picture === "string" ? payload.picture : undefined,
      };
      if (!claims.sub || !claims.email || !claims.email_verified) throw new Error("Google email is not verified");

      const openId = `google:${claims.sub}`;
      const role = claims.email === ENV.googleOwnerEmail.toLowerCase() ? "admin" : "user";
      await db.upsertUser({
        openId,
        name: claims.name || null,
        email: claims.email,
        loginMethod: "google",
        role,
        lastSignedIn: new Date(),
      });

      const sessionToken = await createGoogleSession(claims);
      res.cookie(GOOGLE_SESSION_COOKIE, sessionToken, { ...getSessionCookieOptions(req), maxAge: ONE_YEAR_MS });
      res.redirect(302, signedState.returnTo);
    } catch (error) {
      console.error("[Google OAuth] Callback failed", error instanceof Error ? error.message : "unknown error");
      res.status(500).json({ error: "Google OAuth callback failed" });
    }
  });
}
